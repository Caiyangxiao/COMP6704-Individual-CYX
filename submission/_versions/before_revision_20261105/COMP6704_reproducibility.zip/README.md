# COMP6704 个人作业：无约束优化 CPU 实验

姓名：Yangxiao Cai；学号：26023041r。  
一级方向：**Unconstrained Optimization（无约束优化）**。  
主题：比较 GD、非线性共轭梯度和 BFGS 在非凸 Rosenbrock、Rastrigin 函数上的表现。

本项目已完成两个函数、2／10／20 维、每组五个配对起点、三种方法的 **90 次正式求解**。
原始输出、离线分析和复现工具随代码提供。GD 与 Armijo 回溯自行实现；
CG、BFGS 调用 SciPy，算法机制与实现来源在英文报告中明确说明。

## 1. 交付文件与代码获取

| 外层交付路径 | 内容 |
|---|---|
| `submission/Yangxiao Cai+26023041r.pdf` | 使用官方 NeurIPS 2025 样式的英文报告，内嵌完整代码／数据 ZIP 附件 |
| `submission/Yangxiao Cai+26023041r.docx` | 相同英文内容的可编辑课程适配稿，不是官方 Word 模板 |
| `submission/COMP6704_reproducibility.zip` | 完整代码、原始数据、报告源、官方模板和资产；与 PDF 同名附件对应 |
| `submission/COMP6704_NeurIPS2025_论文模板.zip` | 独立论文模板包：官方样式／示例、已填充的 `report.tex` 和配套资产 |

官方文件保存在 `paper_source/template/`；PDF 使用未修改的 `neurips_2025.sty`，
只在主文档中将会议说明替换为课程说明。官方版式为 US Letter 纸张、5.5 × 9 英寸正文区、
正文 10 pt／11 pt 行距。Word 以相同内容和尺寸制作可编辑适配稿，不声称存在官方 NeurIPS Word 模板。
报告验收上限是**含参考文献不超过 10 页**，不要求恰好 10 页。构建步骤见第 9 节。

下载**原始 PDF**后，可在支持附件的阅读器中提取 `COMP6704_reproducibility.zip`。
浏览器的页面预览未必显示附件。代码通过 PDF 附件及独立 ZIP 直接交付，未声称存在公开 GitHub 仓库。
如需用 Python 提取，安装可选依赖 `pypdf==6.10.0` 后执行以下 Python 代码，并调整 PDF 路径：

```python
from pathlib import Path
from pypdf import PdfReader

pdf = Path("submission/Yangxiao Cai+26023041r.pdf")
payload = PdfReader(pdf).attachments["COMP6704_reproducibility.zip"][0]
pdf.with_name("COMP6704_reproducibility_from_pdf.zip").write_bytes(payload)
```

源码 ZIP 不包含交付报告 PDF／Word、ZIP 自身、`.venv`、Python 缓存、旧报告或重复运行结果。
它包含报告重建所需的官方模板材料；独立模板 ZIP 则便于直接编辑并编译已填充的 `report.tex`。
上述报告与独立 ZIP 是外层交付文件，不在解压后的源码树内，避免递归打包。

## 2. 干净解压与安装

将 ZIP 解压到新目录并保留路径结构，进入包含本 README、`configs/`、`cpu_optimization/` 的项目根目录。
所有命令均从项目根目录执行。保持源码原始字节，不要批量转换换行符，否则历史源码哈希会改变。

正式环境为 Python **3.12.8**、NumPy **1.26.4**、SciPy **1.13.1**、Matplotlib **3.10.0**。
`requirements-lock.txt` 记录原 Windows 环境的全部版本；`requirements.txt` 固定三个主要依赖。

Windows PowerShell（确认 `python --version` 为 Python 3.12）：

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
```

Linux／macOS（使用已安装的 Python 3.12）：

```bash
python3.12 --version
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
```

若平台不能安装锁定文件中的某个依赖，可使用 `requirements.txt`，并记录实际版本。
平台、BLAS 或依赖变化后的运行应重新核验，不预设逐位一致。项目环境不依赖原机器的 Anaconda。
后续命令采用 Windows 路径；Linux／macOS 将 `.\.venv\Scripts\python.exe` 替换为 `.venv/bin/python`。
WSL 调用 Windows 环境时可使用 `.venv/Scripts/python.exe`。

## 3. 测试及原始数据核验

测试集含 **28 个 unittest 测试**，部分测试另含多个子场景，覆盖梯度、非凸曲率、Armijo、
零／单次迭代预算、失败试探、非有限点、数值停滞、计数、初值配对、输出防覆盖及失败样本保留。

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe validate_study.py --results results/full_study
```

`validate_study.py` 不运行求解器，核对 90 条汇总、90 个单次 JSON、90 份轨迹、完整实验组合、
30 组配对起点、12 项梯度检查、接受更新与 `nit`、累计／原始调用计数、GD 更新与 Armijo、
独立最终诊断、三类标签及历史源码 SHA-256。存在二维示例时还核对其起点子集。
结果写至 `results/full_study/analysis/validation.json`，通过时为 `passed=true`、`errors=[]`。

原始正式结果含 **80,605 条轨迹事件、80,425 个接受更新**，73 次驻点达标、26 次全局目标阈值命中。
数据核验确认已保存结果的完整性和内部一致性，不等同于在新环境重新完成 90 次求解。

## 4. 离线分析和图表复现

以下命令只读取既有求解数据，更新 `analysis/` 内的派生产物：

```powershell
.\.venv\Scripts\python.exe analyze_results.py --results results/full_study --plot
.\.venv\Scripts\python.exe make_paper_figures.py --results results/full_study --output results/full_study/analysis/paper_figures
```

| 路径（相对 `results/full_study/`） | 内容 |
|---|---|
| `summary.csv`、`runs/`、`traces/` | 90 次求解汇总、单次 JSON 和逐事件 CSV |
| `initial_points.json` | 30 组实际起点，三种方法逐点共享 |
| `gradient_checks.json` | 非驻点上的有限差分核对 |
| `config_resolved.json`、`metadata.json` | 冻结配置、历史环境、来源和完成状态 |
| `analysis/grouped_results.csv` | 18 组统计，五起点中位数／范围，包含失败样本 |
| `analysis/initial_point_comparison.csv` | 30 组初值的三方法配对结果 |
| `analysis/paired_comparisons.csv` | 成本比及终点质量标签，须结合质量共同解释 |
| `analysis/run_diagnostics.csv` | 全部运行的终止、曲率和末步诊断 |
| `analysis/nonstationary_runs.csv` | 17 次未达到梯度阈值的案例 |
| `analysis/stationary_non_global_runs.csv` | 47 次驻点达标但未命中全局目标的案例 |
| `analysis/analysis_summary.json` | 总体及分组统计的完整精度结果 |
| `analysis/validation.json` | 独立核验与错误列表 |
| `analysis/figures/`、`analysis/paper_figures/` | 全量分析图及正式报告用图 |

对数显示下限不改变原始数值；已终止曲线不延长或用末值补齐。
代表性轨迹不替代全量汇总。离线 Hessian 谱及其他诊断不计入求解预算。

## 5. 在新目录重新求解

保留原正式数据，使用新的输出目录：

```powershell
.\.venv\Scripts\python.exe run_experiments.py --config configs/full_study.json --output results/full_study_repeat01 --threads 1
.\.venv\Scripts\python.exe validate_study.py --results results/full_study_repeat01
.\.venv\Scripts\python.exe analyze_results.py --results results/full_study_repeat01 --plot
```

运行器拒绝覆盖非空目录；若 `full_study_repeat01` 已存在，换一个新名称。
小规模检查可使用 `configs/demo_2d.json` 并另选输出目录：两个函数各一个二维起点，共六次求解。

新旧结果应逐 `run_id` 比较初值、配置、状态、目标值、梯度及 `nit/nfev/njev`，并记录环境差异。
同一环境的确定性数值路径与评估成本是重点；**墙钟时间不要求相等**。
跨硬件或数值库的浮点差异可能改变严格阈值附近的终止状态。
只有完成该次运行和核验后，才可对新环境复现作出结论。

本项目提供逐运行、逐事件的严格比较器（排除耗时字段）：

```powershell
.\.venv\Scripts\python.exe paper_source/verify_reproduction.py --reference results/full_study --candidate results/full_study_repeat01 --output submission/reproduction_verification.json
```

外层交付的 `submission/reproduction_verification.json` 记录本次交付前的独立重跑核验；
该环境中的数值一致性不代替新机器自己的核验。

`--threads 1` 在导入 NumPy 前设置当前子进程的 BLAS／OpenMP 线程变量，不修改系统设置。
方法依次执行，不并发计时；直接导入模块时由调用者先设置线程。

## 6. 固定实验协议

| 项目 | 设置 |
|---|---|
| 函数／维度 | Rosenbrock、Rastrigin；2、10、20 维 |
| 起点 | 每个函数／维度五个，基础种子 `20261105` |
| 起点分布 | Rosenbrock 每坐标 `Uniform[-2,2]`；Rastrigin 每坐标 `Uniform[-3,3]` |
| 公共停止指标 | float64；梯度二范数不超过 `1e-6`；最多 5000 个接受更新 |
| 全局目标标签 | 有限结果且 `abs(f_final-f_star)<=1e-6`；两函数 `f_star=0` |

初始化区间不限制后续迭代。每个函数／维度使用
`PCG64 / SeedSequence([seed, objective_index, dimension])`，保存实际坐标。
增加其他维度或同组起点数量不会改变已有起点前缀。

- **GD：** 自写 Armijo 回溯，`alpha0=1, c1=1e-4`，缩步比例 `0.5`，最小步长 `1e-12`。
  `max_backtracks=50` 表示初次试探后最多缩步 50 次，至多 51 次试探，也可能先达到最小步长。
  失败步不更新；非有限值与不变浮点步分别记为失败状态。
- **CG：** SciPy 非线性 PR+ CG，解析梯度，`norm=2, gtol=1e-6, c1=1e-4, c2=0.4`。
  区别于线性 CG／Newton-CG；具体充分下降保障以 SciPy 1.13.1 源码为准。
- **BFGS：** SciPy 普通 BFGS，解析梯度，默认单位初始逆 Hessian，
  `norm=2, gtol=1e-6, c1=1e-4, c2=0.4, xrtol=0`。这里 `c2` 不采用库默认 `0.9`。

Rosenbrock 使用 SciPy `rosen/rosen_der`。Rastrigin 使用数学等价的稳定形式
`sum(x_i**2 + 20*sin(pi*x_i)**2)`，梯度为 `2*x_i + 20*pi*sin(2*pi*x_i)`。
梯度预检查采用中心差分，`h_i=1e-6*max(1,abs(x_i))`，按分量 `atol=rtol=1e-5` 判断；不进入求解预算。

## 7. 计数、计时与复杂度边界

所有实际求解函数／梯度调用经过 `EvaluationCounter`，包括被拒绝的线搜索试探。
SciPy 命中缓存而未调用原始函数时不额外计数。CG／BFGS 的包装器计数必须与原始 `nfev/njev` 一致。

| 事件 | 含义 |
|---|---|
| `initial` | 起始坐标，`iteration=nfev=njev=0`；图示诊断离线补算，求解器自身初值评估照常计数 |
| `accepted` | 一个接受更新；复制坐标与已有累计计数，回调不额外评估 |
| `terminal` | 最终坐标及全部计数，不增加 `nit`；失败试探可增加计数但不改变坐标 |

计时包含正常初始化、试探、更新及统一轨迹记录；不含输入校验、导入、离线诊断、绘图或文件写入。
求解结束后使用原始函数／梯度填充诊断，不经过计数器，也不计入已结束的计时。
JSON 非有限数写为 `null`，CSV 保留 `nan/inf`；失败运行不删除。

保留三类独立判定：原始 `solver_success/solver_status/solver_message`、公共 `stationary` 和 `global_hit`。
本批前两者恰好同为 73 次，并非概念等同。15 次 Rosenbrock-GD 耗尽迭代预算；
两次 Rastrigin 20 维 BFGS 精度损失终止，均未达到公共梯度阈值。
梯度小不保证全局最优，目标阈值命中也不保证梯度达标。

同一迭代上限不等于同一计算预算，一次函数调用也不等于一次梯度调用。
GD 回溯与库方法的 Wolfe 线搜索不同，不能只将迭代差异归因于方向。
小维度墙钟时间受解释器、日志和系统噪声影响，仅作辅助证据。

GD／CG 的方向与状态成本为 `O(d)`。标准高效 BFGS 更新可为 `O(d²)`；
但 SciPy 1.13.1 更新含通用稠密矩阵乘法，按常规实现为 `O(d³)`，状态和方向计算为 `O(d²)`。
这些成本不含函数／梯度及日志：两函数每次函数／梯度评估为 `O(d)`；
保存 K 个 d 维点另需 `O(Kd)` 空间与总复制时间。2–20 维计时不足以验证渐近阶。

## 8. 来源与哈希

原 `metadata.json` 保留历史运行环境、线程、起点生成方式及源码 SHA-256。
其中旧机器绝对路径仅作来源记录，不是新电脑运行所需路径。
`analysis/analysis_provenance.json` 与图表来源 JSON 分别记录后续分析及绘图来源。
新增分析、核验和文档模块晚于求解，原元数据的历史源码列表保持原样。

核验器只检查原元数据已记录文件及 SciPy 求解源码，不要求旧列表包含后来新增模块。
哈希失配时检查源码修改、换行符和 SciPy 来源，保留差异；不要改写预期哈希以制造通过结果。

## 9. 官方 NeurIPS 2025 PDF 与可编辑 Word 的重建

数值求解及统计不需要文档依赖。重建报告时安装 Python 文档依赖：

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-report.txt
```

另安装带 XeLaTeX 的 TeX Live／MiKTeX，或安装 Tectonic 并使 `tectonic` 命令可用。
TeX 引擎和便携版引擎程序不随复现包分发；首次编译可能需要下载宏包和字体。
Python 文档依赖不代替 TeX 引擎。

正文源为 `paper_source/content.json`，公式源为 `paper_source/equations.json`，
`paper_source/generate_latex.py` 生成 `paper_source/template/report.tex`。
官方 `neurips_2025.sty` 和示例文件位于同一模板目录；样式文件保持原样，
课程说明在主文档中覆盖，正文尺寸仍为 US Letter 上的 5.5 × 9 英寸、10 pt／11 pt 行距。
源码包已保留正文与图片／公式资产，重建现有报告不必重新求解或重新生成分析图。

先生成 LaTeX，再编译官方样式 PDF。以下 Tectonic 命令从项目根目录执行：

```powershell
.\.venv\Scripts\python.exe paper_source/generate_latex.py
New-Item -ItemType Directory -Force submission/_latex | Out-Null
tectonic --keep-logs --outdir submission/_latex paper_source/template/report.tex
```

使用 XeLaTeX 时，从模板目录运行并将输出写入同一构建目录；运行两遍以解析交叉引用：

```powershell
New-Item -ItemType Directory -Force submission/_latex | Out-Null
Push-Location paper_source/template
xelatex -interaction=nonstopmode -halt-on-error -output-directory ../../submission/_latex report.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory ../../submission/_latex report.tex
Pop-Location
```

正文、资产、模板和 README 定稿后，重新生成完整复现包。打包工具使用标准库，
保留原始文件字节，并校验归档成员及原始七份求解源码哈希：

```powershell
.\.venv\Scripts\python.exe paper_source/package_reproducibility.py --dry-run
.\.venv\Scripts\python.exe paper_source/package_reproducibility.py
.\.venv\Scripts\python.exe paper_source/package_reproducibility.py --verify-only
```

将已验证的独立包放在 `submission/COMP6704_reproducibility.zip`，随后以编译结果作为正式 PDF 页面源：

```powershell
.\.venv\Scripts\python.exe paper_source/build_final_report.py --latex-pdf submission/_latex/report.pdf
```

该步骤输出正式 PDF 与同一英文内容的 Word 适配稿，并将代码／数据 ZIP 嵌入 PDF。
Word 是可编辑课程版本，不能称为官方 Word 模板；正式 PDF 的版式依据是官方 `.sty` 的编译结果。
独立 `submission/COMP6704_NeurIPS2025_论文模板.zip` 包含官方材料、已填充论文与资产；
完整代码 ZIP 同样保留这些模板源文件。

没有准备附件时，可单独生成预览：

```powershell
.\.venv\Scripts\python.exe paper_source/build_final_report.py --no-attachment --latex-pdf submission/_latex/report.pdf
```

`--no-attachment` 的产物位于 `submission/_preview/`，不会覆盖正式 PDF／Word，
也不能作为声称含代码附件的最终交付。添加 `--render-preview` 需另装 `pypdfium2`。
可选的 `paper_source/export_word_pdf.ps1` 用于检查 Windows 上的 Word 排版；
正式 PDF 仍使用上述 `--latex-pdf` 流程。排版验收以实际页数**不超过 10 页（含参考文献）**为准。

原始 90 次数值结果保持不变。本轮独立离线审计从单次 JSON 和轨迹重新核对，
记录 **782,401 项检查、0 项错误**；证据为
`audits/final_review_20261105/numerical_claims_audit.json`。
这项数值审计不调用求解器；测试执行和新目录重跑分别使用第 3、5 节命令核验。

`archive_manifest.json` 记录成员大小与 SHA-256，
外层 `submission/packaging_verification.json` 保存临时解包核验结果。
源码包保留原始日志、统计表、官方模板与正式报告资产，省略可由日志再生的大幅分析图。
重新生成派生文件后，旧清单只适用于旧归档，应重新打包并更新 PDF 中的附件。
文档重建不调用求解器；更改数据时须同步审阅正文、统计和图表。
最终 PDF 应不超过 10 页且小于 20 MB，嵌入附件计入文件大小。

## 10. 目录与入口

| 路径 | 职责 |
|---|---|
| `cpu_optimization/objectives.py` | 目标、解析梯度和梯度检查 |
| `cpu_optimization/solvers.py` | GD、SciPy 接口、预算计数和事件 |
| `cpu_optimization/experiment.py` | 配置、配对起点、来源与原始输出 |
| `cpu_optimization/analysis.py` | 全量统计、配对比较和终止诊断 |
| `cpu_optimization/` 中的绘图模块 | 既有数据的离线图表 |
| `run_experiments.py` | 新目录求解入口 |
| `analyze_results.py`、`plot_results.py`、`make_paper_figures.py` | 离线分析和绘图入口 |
| `validate_study.py` | 独立协议、数据及来源核验 |
| `configs/`、`tests/` | 冻结配置及 28 项测试 |
| `requirements*.txt` | 主要依赖、原环境锁定、可选文档依赖 |
| `results/full_study/` | 正式原始结果和派生分析 |
| `paper_source/` | 英文正文源与报告构建器 |

理论与近期论文见英文报告参考文献。实现资料包括 SciPy 1.13.1 的
[CG 文档](https://docs.scipy.org/doc/scipy-1.13.1/reference/optimize.minimize-cg.html)、
[BFGS 文档](https://docs.scipy.org/doc/scipy-1.13.1/reference/optimize.minimize-bfgs.html)及
[对应源码](https://github.com/scipy/scipy/blob/v1.13.1/scipy/optimize/_optimize.py)。
